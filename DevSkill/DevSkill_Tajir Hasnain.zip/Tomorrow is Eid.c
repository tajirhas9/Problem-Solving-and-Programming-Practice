#include <stdio.h>
int main()
{
    int n;
    scanf("%d",&n);
    if(n >= 30)
        printf("YES");
    else
        printf("NO");
    return 0;
}
